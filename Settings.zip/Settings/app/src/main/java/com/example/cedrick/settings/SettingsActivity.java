package com.example.cedrick.settings;

import android.app.Activity;
import android.content.SharedPreferences;
import android.preference.SwitchPreference;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SwitchCompat;
import android.support.v7.widget.ViewUtils;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;

import static android.graphics.Color.blue;

public class SettingsActivity extends AppCompatActivity {
    private static final String PREFS_NAME = "prefs";
    private static final String PREF_DARK_THEME = "dark_theme";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);


   Switch mySwitch = (Switch) findViewById(R.id.mySwitch);
        Boolean switchState = mySwitch.isChecked();


 mySwitch.setOnClickListener(new View.OnClickListener() {
     @Override
     public void onClick(View v) {

         boolean mySwitch=true;

  themeUtils.changeToTheme
     }
 });
    }

}
